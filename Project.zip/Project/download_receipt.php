<button onclick="goBack()" class="btn btn-info">Back</button>

<script>
function goBack() {
  window.history.back();
}
</script>